#ifndef __SCHEDULE_H__
#define __SCHEDULE_H__

#include "x86.h"
#include "common.h"
#include "device.h"

void schedule(void);
void change_state(void);

#endif
