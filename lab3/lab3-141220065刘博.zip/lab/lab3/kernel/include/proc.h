#ifndef __PROC_H__
#define __PROC_H__

#include "process/pcb.h"
#include "process/schedule.h"

#define SYS_fork 20
#define SYS_sleep 21
#define SYS_exit 22
#define time_chips 1

#endif
