#include "lib.h"

void main()
{
	print("Process:Hello world!",8,0);
	print("3.1415926",9,0);
}
