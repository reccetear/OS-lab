#ifndef __DEVICE_H__
#define __DEVICE_H__

#include "device/serial.h"

#endif
